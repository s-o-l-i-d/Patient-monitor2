﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientMonitor1._4
{
    class AlarmClass
    {
        Boolean basic_alarm = false;
        Boolean advaced_alarm = false;

        double pulse;
        double breathing;
        double blood_systolic;
        double blood_diastolic;
        double temperature;

        static double min_pulse = 10;
        static double min_breathing = 10;
        static double min_blood_systolic = 10;
        static double min_blood_diastolic = 10;
       static  double min_temperature = 10;

        static double max_pulse = 30;
        static double max_breathing = 30;
        static double max_blood_systolic = 30;
       static  double max_blood_diastolic = 30;
        static double max_temperature = 30;

        //method to change min and max value limits
         public void ChangeMinMax(int min, int max, string selection)
        {
            //read trough selection
            //if selection is "pulse"
            //change min and max values according to user selection
            if (selection == "Pulse")
            {
                min_pulse = min;
                max_pulse = max;
                
            }
            //do the same for breathing
            if (selection == "Breathing")
            {
                min_breathing = min;
                max_breathing = max;
            }
            //and so on with systolic/Diastolic blood pressure and temperature as well
            if (selection == "Systolic Blood Pressure")
            {
                min_blood_systolic = min;
                max_blood_systolic = max;

            }
            if (selection == "Diastolic Blood Pressure")
            {
                min_blood_diastolic = min;
                max_blood_diastolic = max;
            }
            if (selection == "Temperature")
            {
                min_temperature = min;
                max_temperature = max;
            }
        }
            // perform logic
            /*
            if (pulse<min_pulse) { basic_alarm = true; }
            if (pulse > max_pulse) { basic_alarm = true; }
            if (breathing<min_breathing) { basic_alarm = true; }
            if (breathing > max_breathing) { basic_alarm = true; }
            if (blood_diastolic<min_blood_diastotic) { basic_alarm = true; }
            if (blood_diastolic > max_blood_diastotic) { basic_alarm = true; }
            if (blood_systolic<min_blood_systolic) { basic_alarm = true; }
            if (blood_systolic > max_blood_systolic) { basic_alarm = true; }
            if (temperature<min_temperature) { basic_alarm = true; }
            if (temperature > max_temperature) { basic_alarm = true; }

            if (pulse == 0) { advanced_alarm = true; }
            if (breathing == 0) { advanced_alarm = true; }
            if (blood_diastolic == 0) { advanced_alarm = true; }
            if (blood_systolic == 0) { advanced_alarm = true; }
            if (temperature == 0) { advanced_alarm = true; }
            
            
            // trigger alarm
            */
    }
}
