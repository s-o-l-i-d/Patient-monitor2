﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PatientMonitor1._4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            CSVReader myNewCSVReader = new CSVReader();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //create an instance of CSVReader class
            CSVReader myNewCSVReader = new CSVReader();

            //call the method readFromCSVFile and store the resulting array into patient1DataArray
            object[]patient1DataArray = myNewCSVReader.readFromCSVFile();

            //change the text on patient1 labels to display the readings from the array
            P1PulseLabel.Text = "Pulse: " + patient1DataArray[0];
            patient1BreathingLabel.Text = "Breathing Rate: " + patient1DataArray[1];
            patient1SysBloodLabel.Text = "Systolic Blood Pressure: " + patient1DataArray[2];
            patient1DiasBloodLabel.Text = "Diastolic Blood Pressure: " + patient1DataArray[3];
            patient1TemperatureLabel.Text = "Temperature: " + patient1DataArray[4];



        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void patient1SetButton_Click(object sender, EventArgs e)
        {
            //Create a new instance of the Alarm Class
            AlarmClass myNewAlarmClass = new AlarmClass();

            //Read user selection from the drop down menu, and store it into a string
            //code from https://social.msdn.microsoft.com/Forums/en-US/dfe62a93-0b35-41ef-9858-7fa22980f1a5/how-to-get-combobox-text-in-a-string?forum=csharplanguag
            string selection = patient1SetCombo.SelectedItem.ToString();

            //Tests that user selection works by displaying the value on the label 
            //below min max value choosing box
            //will be removed when the program is ready
            testLabel.Text = selection;

            //read the user given number from textboxes
            //and store them into integers
            int min = int.Parse(minPatient1.Text);
            int max = int.Parse(maxPatient1.Text);

            //Test the user selection by displaying the selection, min and max
            //on the label below the min max changing box
            //will be removed once the code is ready
            testLabel.Text = selection + min + max;

            //call the ChangeMinMax method 
            //with selection, min and max values
            myNewAlarmClass.ChangeMinMax(min, max, selection);

            //Display the min and max values on the labels
            if (selection == "Pulse")
            {
                pulseMinMaxLabel.Text = "Min: " + minPatient1.Text + "Max: " + maxPatient1.Text;
            }
            if (selection == "Breathing Rate")
            {
                breathingMinMaxLabel.Text = "Min: " + minPatient1.Text + " Max: " + maxPatient1.Text;
            }


        }

        private void testLabel_Click(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
