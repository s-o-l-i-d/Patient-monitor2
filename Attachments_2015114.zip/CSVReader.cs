﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientMonitor1._4
{
    class CSVReader
    {
        //Methods and attributes to display data from CSV files 
        //on the GUI

        //Declare variables to store the file path
        protected static string readline;
        protected static string readpath = @"C:\Users\Ava\Documents\patient-monitoring\Bed12.csv";


        //declare variables to contain data red from the file
        public static string pulse;
        public static string breathing;
        public static string blood_systolic;
        public static string blood_diastolic;
        public static string temperature;
        

        //method to read data from the CSV file  return it as 5 strings containing the numeric values
        public object[] readFromCSVFile()
        {
            //code from:https://msdn.microsoft.com/en-us/library/f2ke0fzy(v=vs.110).aspx

            //Connect to streamreader using the filepath
            using (System.IO.StreamReader readings = new System.IO.StreamReader(readpath))
            {
                //loop trough the file
                readings.ReadLine();
                int tick = 0;
                while (readings.Peek() >= 0)
                {
                    tick = tick + 1;
                    readline = readings.ReadLine();

                    //contain the red values into string variables
                    pulse = readline.Split(',')[0];
                    breathing = readline.Split(',')[1];
                    blood_systolic = readline.Split(',')[2];
                    blood_diastolic = readline.Split(',')[3];
                    temperature = readline.Split(',')[4];

                    

                    
                }

                //set values into an array, and return the array
                string[] ret = { pulse, breathing, blood_systolic, blood_diastolic, temperature };
                return ret;
            }
        }
    }
}
